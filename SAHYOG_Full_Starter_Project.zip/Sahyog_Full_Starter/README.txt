SAHYOG — Starter project

FILES
- index.html: main website (homepage, worker/business registration, listings,
  business-specific Join application, buy/sell products with up to 3 photos,
  public advertisements, admin-only ad publishing and moderation).
- firestore.rules: Firestore access rules.
- storage.rules: Storage upload/read rules.

SETUP
1. Create a Firebase project.
2. Register a Web App in Firebase and copy its config into index.html.
3. Enable Authentication > Email/Password. Create your admin login.
4. Copy the admin user's UID into ADMIN_UID in index.html and replace
   PASTE_ADMIN_UID in both rules files with the same UID.
5. Create Firestore Database and paste firestore.rules into Firestore Rules.
6. Enable Firebase Storage and paste storage.rules into Storage Rules.
7. Deploy index.html with GitHub Pages (or another static host).\n8. Admin login page: open your site URL with ?admin=1 at the end. The login\n   form is shown on that route; after authentication, the configured admin UID\n   alone gets the control panel. The UID checks and Firebase rules are the real\n   security boundary, not the URL.

IMPORTANT NOTES
- Listings are submitted as "pending"; the admin must approve them before
  they appear publicly. The admin approval panel is visible only to the UID
  configured above.
- Public listing documents intentionally do not contain phone numbers.
- This is a starter MVP, not a fully audited production marketplace.
- Add Firebase App Check, abuse protection, stronger validation, consent and
  privacy notices, reporting/blocking, business verification, and legal review
  before public launch. Firebase billing/Storage availability and pricing can
  change; check the current Firebase console plan.
- Because this platform may connect strangers, do not publish personal contact
  details or arrange work involving minors without parent/guardian oversight.
